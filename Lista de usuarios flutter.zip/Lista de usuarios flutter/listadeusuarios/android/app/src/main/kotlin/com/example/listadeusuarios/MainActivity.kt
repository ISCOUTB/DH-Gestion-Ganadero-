package com.example.listadeusuarios

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
